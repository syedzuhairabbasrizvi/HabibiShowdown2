#pragma once

#include "character.hpp"

class PlayerCharacter : public Character {
private:
    string playerName;
    int playerNo;

public:
    // constructor
    PlayerCharacter(std::string n, int h, int s, string pN, int pNo);

    void InputProcessor();
};
