# HabibiShowdown2
An Object Oriented Programming and Design Methodologies project for the course Object Oriented Programming and Design Methodologies created using C++, SDL, and the knowledge of Object Oriented Programming and Design Methodologies.

Current status: shows an image saved in downloads.

Update image path according to your machine (line 55).

Compile command:
g++ -g SDLHelper.cpp MatchManager.cpp main2.cpp -IC:\mingw_dev_lib\include\SDL2 -LC:\mingw_dev_lib\lib 
-w -lmingw32 -lSDL2main -lSDL2 -lSDL2_image
